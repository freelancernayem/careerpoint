

$(document).ready(function ($) {
	
	$('.form-content .select-crs-box .crs-nm-bx .crs-box').on('click', function () {
		$(this).toggleClass('active')
	});

}(jQuery));

